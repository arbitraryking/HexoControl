# Star's Tech Blog

框架驱动：[Hexo](https://hexo.io/zh-cn/)  

博客主题：[NexT ^6.x](https://github.com/theme-next/hexo-theme-next)

## Hexo 搭建

Hexo 官方文档：https://hexo.io/docs/


## 主题配置

NexT 官方文档：https://theme-next.org/docs/getting-started/


## 第三方服务

### 阅读量

LeanCloud：https://www.leancloud.cn/

### 评论

Valine：https://valine.js.org/

### 统计

百度统计：https://tongji.baidu.com/

### 收录

百度收录：https://ziyuan.baidu.com/    

Google Search Console: https://search.google.com/search-console




