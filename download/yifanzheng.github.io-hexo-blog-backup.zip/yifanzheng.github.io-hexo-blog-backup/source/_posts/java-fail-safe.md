---
title: 一文读懂 Java 集合中的快速失败(fail-fast)和安全失败(fail-safe)机制
author: Star.Y.Zheng
comments: true
categories: Java
abbrlink: bb83d678
date: 2020-07-20 22:15:11
tags:
---

### 快速失败

采用快速失败机制的集合容器，使用迭代器进行遍历集合时，除了通过迭代器自身的 `remove()` 方法之外，对集合进行任何其他方式的结构性修改，则会抛出 ConcurrentModificationException 异常。

在 `java.util` 包下的集合类都采用的是快速失败机制，不能在多线程下发生并发修改（迭代过程中被修改）。
<!-- more -->
**原理**

迭代器在遍历时直接访问集合的内容时，因此集合中的内容在遍历的过程中无法被修改。为了保证不被修改，迭代器内部维护了一个 modCount 变量 ，当集合结构改变（添加、删除或者修改），就会改变 modCount 的值。每当迭代器使用 hasNext() 和 next() 方法遍历下一个元素之前，都会检查 modCount 的值是否等于 expectedmodCount 的值，当检测到 `modCount != expectedmodCount` 时，抛出 ConcurrentModificationException 异常，反之继续遍历。

> 注意: 迭代器的快速失败机制是无法得到保证的，这里异常的抛出条件是检测到 `modCount != expectedmodCount` 这个条件。如果集合发生变化时 modCount 的值刚好等于 expectedmodCount 的值，则异常不会抛出。因此，为提高这类迭代器的正确性而编写一个依赖于此异常的程序是错误的做法，迭代器的快速失败机制应该仅用于检测 bug。

**优缺点**

- 单线程下效率相对较高。
- 多线程环境下，线程不安全。

这里排除 HashTable。
### 安全失败

采用安全失败机制的集合容器，使用迭代器进行遍历时不是直接在集合内容上访问的，而是将原有集合内容进行拷贝，在拷贝的集合上进行遍历。  

**原理**

迭代器在遍历时访问的是拷贝的集合，所以在遍历过程中对原集合所作的修改并不能被迭代器检测到，所以不会触发 ConcurrentModificationException 异常。

**优缺点**

- 由于对集合进行了拷贝，避免了 ConcurrentModificationException 异常，但拷贝时产生大量的无效对象，开销大。
- 无法保证读取到的数据是原集合中最新的数据，即迭代器进行遍历的是拷贝的集合，在遍历期间原集合发生的修改，迭代器是检测不到的。

### 特别说明

结构性修改：指改变集合大小的修改。

非结构性修改：指不涉及集合大小的修改。

本文所提到的“修改”指的是“结构性修改”。也就是说，如果只是改变集合中元素本身的内容，不会触发快速失败机制。