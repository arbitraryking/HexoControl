---
title: 关于
date: 2019-11-25 20:21:43
type: "about"
layout: "about"
comments: false
---

一名菜鸟程序员，持续学习者，Java 开发者，Angular 爱好者。经常分享关于编程、思考相关的内容，希望给来到这里的人有所帮助。  